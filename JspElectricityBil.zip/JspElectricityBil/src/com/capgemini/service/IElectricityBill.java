package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.dao.IElectricityDao;

public interface IElectricityBill {

	int addConsumerDetails(ElectricityBean bean);

	String isValidateConsumerNumber(int consumerNumber);

	ElectricityBean searchConsumerDetails(int consumerNumber);

	List<ElectricityBean> showBillDetails(int consumerNumber);

	List<ElectricityBean> showConsumerDetails();

	
}
