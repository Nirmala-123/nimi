package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.dao.ElectricityDaoImpl;
import com.capgemini.dao.IElectricityDao;

public class ElectricityBillImpl implements IElectricityBill{
	IElectricityDao dao;
	@Override
	public int addConsumerDetails(ElectricityBean bean) {
		dao=new ElectricityDaoImpl();
		int billId=dao.addConsumerDetails(bean);
		return billId;
		
	}

	@Override
	public String isValidateConsumerNumber(int consumerNumber) {
		dao=new ElectricityDaoImpl();
		String consumerName=dao.isValidateConsumerNumber(consumerNumber);
		return consumerName;
		
	}

	@Override
	public ElectricityBean searchConsumerDetails(int consumerNumber) {
		dao=new ElectricityDaoImpl();
		ElectricityBean consbean=dao.searchConsumerDetails(consumerNumber);
		return consbean;
	}

	@Override
	public List<ElectricityBean> showBillDetails(int consumerNumber) {
		dao=new ElectricityDaoImpl();
		List<ElectricityBean> showbean=dao.showBillDetails(consumerNumber) ;
		return showbean;
	}

	@Override
	public List<ElectricityBean> showConsumerDetails() {
		dao=new ElectricityDaoImpl();
		List<ElectricityBean> listbean=dao.showConsumerDetails() ;
		return listbean;
		
	}

	
		
	}


