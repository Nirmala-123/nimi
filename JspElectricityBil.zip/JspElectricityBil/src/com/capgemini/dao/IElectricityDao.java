package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.ElectricityBean;

public interface IElectricityDao {
	
	  int addConsumerDetails(ElectricityBean bean);
	  String isValidateConsumerNumber(int consumerNumber);
	  ElectricityBean searchConsumerDetails(int consumerNumber);
	  List<ElectricityBean> showBillDetails(int consumerNumber);
	List<ElectricityBean> showConsumerDetails();
}
