package com.capgemini.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.util.DButil;


public class ElectricityDaoImpl implements IElectricityDao {
	Connection con = null;
	@Override
	public int addConsumerDetails(ElectricityBean bean) {
		int billId=0;
		PreparedStatement pst;
		int query=0;
		try {
			con= DButil.obtainConnection();
			//System.out.println("db Succesfully");
			int consumerNumber=bean.getConsumerNumber();
			pst=con.prepareStatement("Insert INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)");
			pst.setInt  (1,consumerNumber);
			//System.out.println(consumerNumber);
			pst.setFloat(2, bean.getCurrentMonthReading());
			pst.setFloat(3, bean.getUnitConsumed());
			pst.setFloat(4, bean.getNetAmount());
		    query=pst.executeUpdate();
		    if(query==1)
		    {
		    	System.out.println("Inserted in db Succesfully");
		    
		    }
		    else
		    	System.out.println("Not inserted");
		    pst= con.prepareStatement("SELECT seq_bill_num.CURRVAL FROM DUAL");
		    ResultSet rs=pst.executeQuery();
		    while(rs.next())
		    {
		    	billId=rs.getInt(1);
		    }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return billId;
		
		
		
	}

	@Override
	public String isValidateConsumerNumber(int consumerNumber) {
		String consumerName = null;
		con= DButil.obtainConnection();
		try {	
			PreparedStatement pst=con.prepareStatement("Select consumer_name from consumers where consumer_num=?");
			pst.setInt(1,consumerNumber);
			ResultSet rs=pst.executeQuery();
			rs.next();
			consumerName=rs.getString("consumer_name");
			
			
		}   catch (SQLException e) {
			
			e.printStackTrace();
		}
		return consumerName;
		
	}

	@Override
	public ElectricityBean searchConsumerDetails(int consumerNumber) {
		con=DButil.obtainConnection();
		ElectricityBean consbean=new ElectricityBean();
		try {
			
			PreparedStatement pst=con.prepareStatement("Select consumer_name,address from consumers where consumer_num=?");
			pst.setInt(1,consumerNumber);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				consbean.setConsumerName(rs.getString("consumer_name"));
				consbean.setAddress(rs.getString("address"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return consbean;
	}

	@Override
	public List<ElectricityBean> showBillDetails(int consumerNumber) {

		con=DButil.obtainConnection();
		List<ElectricityBean> beanlist=new ArrayList<ElectricityBean>();
		
		try {
			
			PreparedStatement pst=con.prepareStatement("SELECT bill_num,to_char(bill_date,'month'),cur_reading,unitconsumed,netamount from billdetails where consumer_num=?");
			pst.setInt(1,consumerNumber);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ElectricityBean showbean=new ElectricityBean();
				showbean.setBillId(rs.getInt("bill_num"));
				showbean.setBillMonth(rs.getString(2));
				showbean.setCurrentMonthReading(rs.getFloat("cur_reading"));
				showbean.setUnitConsumed(rs.getFloat("unitconsumed"));
				showbean.setNetAmount(rs.getFloat("netamount"));
				beanlist.add(showbean);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return beanlist;
	}

	@Override
	public List<ElectricityBean> showConsumerDetails() {
		con=DButil.obtainConnection();
		List<ElectricityBean> listbean=new ArrayList<ElectricityBean>();
try {
			
			PreparedStatement pst=con.prepareStatement("SELECT * from consumers");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ElectricityBean showbean=new ElectricityBean();
				showbean.setConsumerNumber(rs.getInt(1));
				showbean.setConsumerName(rs.getString(2));
				showbean.setAddress(rs.getString(3));
				listbean.add(showbean);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return listbean;
	}

}
