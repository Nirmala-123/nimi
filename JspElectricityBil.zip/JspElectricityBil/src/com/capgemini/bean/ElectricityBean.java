package com.capgemini.bean;

public class ElectricityBean {
	private int consumerNumber;
	private int billId;
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	private String billMonth;
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	private String consumerName;
	private String address;
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	private float lastMonthReading;
	private float currentMonthReading;
	private float unitConsumed;
	private float netAmount;
	public float getLastMonthReading() {
		return lastMonthReading;
	}
	public void setLastMonthReading(float lastMonthReading) {
		this.lastMonthReading = lastMonthReading;
	}
	public float getCurrentMonthReading() {
		return currentMonthReading;
	}
	public void setCurrentMonthReading(float currentMonthReading) {
		this.currentMonthReading = currentMonthReading;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public int getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	

}
