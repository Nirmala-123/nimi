package com.capgemini.modulescore.dao;

public interface IQueryMapper {
	public final static String FETCH_TRAINEES="SELECT trainee_id FROM trainees";
	public final static String INSERT_ASSESSMENT_SCORE="INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)";
	public final static String TRAINEE_AVAIL="SELECT count(*) FROM assessmentscore WHERE trainee_id=? AND module_name=?";
}
