package com.capgemini.modulescore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.capgemini.modulescore.bean.ModuleScoreBean;
import com.capgemini.modulescore.exception.ModuleScoreException;
import com.capgemini.modulescore.util.DBConnection;
public class IModuleScoreDaoImpl implements IModuleScoreDao{

	
	//------------------------ 1.Module Score Management System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	fetchTrainees()
		 - Input Parameters	:	void
		 - Return Type		:	ArrayList<ModuleScoreBean>
		 - Throws			:  	ModuleScoreException,SQLException
		 - Author			:	S.Venkata Sai Kumar
		 - Creation Date	:	02/7/2018
		 - Description		:	Fetching traineeid for displaying it in form.
		 ********************************************************************************************************/
	@Override
	public ArrayList<ModuleScoreBean> fetchTrainees() throws ModuleScoreException, SQLException {
		Connection con=null;
		PreparedStatement stmt=null;
			ArrayList<ModuleScoreBean> traineeId=new ArrayList();
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.FETCH_TRAINEES);
			ResultSet rs=stmt.executeQuery();
			while(rs.next()){
				ModuleScoreBean module=new ModuleScoreBean();
				module.setTraineeId(rs.getInt(1));
				traineeId.add(module);
			}
			
			con.close();
			stmt.close();
			return traineeId;
	}

	
	//------------------------ 1.Module Score Management System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addAssessmentScore(ModuleScoreBean moduleScore)
			 - Input Parameters	:	ModuleScoreBean
			 - Return Type		:	boolean
			 - Throws			:  	ModuleScoreException,SQLException
			 - Author			:	S.Venkata Sai Kumar
			 - Creation Date	:	02/7/2018
			 - Description		:	Inserting calculated Module Score and Grade along with Trainee details to AssessmentScore
			 ********************************************************************************************************/
	
	
	@Override
	public boolean addAssessmentScore(ModuleScoreBean moduleScore) throws ModuleScoreException, SQLException {
		Connection con=null;
		PreparedStatement stmt=null;
			boolean temp=false;
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.INSERT_ASSESSMENT_SCORE);
			stmt.setInt(1, moduleScore.getTraineeId());
			stmt.setString(2, moduleScore.getModuleName());
			stmt.setInt(3, moduleScore.getMpt());
			stmt.setInt(4, moduleScore.getMtt());
			stmt.setInt(5, moduleScore.getAssignmentScore());
			stmt.setInt(6, moduleScore.getTotal());
			stmt.setInt(7, moduleScore.getGrade());
			int queryResult=stmt.executeUpdate();
			if(queryResult==0){
				throw new ModuleScoreException("Data Not Inserted");
			}
			else
			{
				temp=true;
			}
			con.close();
			stmt.close();
		
			return temp;
		
	}


	//------------------------ 1.Module Score Management System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	traineeCheck(ModuleScoreBean module)
			 - Input Parameters	:	ModuleScoreBean
			 - Return Type		:	boolean
			 - Throws			:  	ModuleScoreException,SQLException
			 - Author			:	S.Venkata Sai Kumar
			 - Creation Date	:	02/7/2018
			 - Description		:	Checking For Trainee
			 ********************************************************************************************************/
	
	
			@Override
			public boolean traineeCheck(ModuleScoreBean module) throws ModuleScoreException, SQLException {
				Connection con=null;
				PreparedStatement stmt=null;
				boolean temp=false;
					con=DBConnection.getConnection();
					stmt=con.prepareStatement(IQueryMapper.TRAINEE_AVAIL);
					stmt.setInt(1, module.getTraineeId());
					stmt.setString(2, module.getModuleName());
					ResultSet rs=stmt.executeQuery();
					while(rs.next()){
						if(rs.getInt(1)==1)
						{
							temp=true;
							break;
						}
						else
						{
							temp=false;
						}
					}
					
					con.close();
					stmt.close();
					return temp;
			}

}
