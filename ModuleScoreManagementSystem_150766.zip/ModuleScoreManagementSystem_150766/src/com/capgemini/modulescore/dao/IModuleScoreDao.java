package com.capgemini.modulescore.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.modulescore.bean.ModuleScoreBean;
import com.capgemini.modulescore.exception.ModuleScoreException;

public interface IModuleScoreDao {
	public ArrayList<ModuleScoreBean> fetchTrainees() throws ModuleScoreException,SQLException;
	public boolean traineeCheck(ModuleScoreBean module) throws ModuleScoreException,SQLException;
	public boolean addAssessmentScore(ModuleScoreBean moduleScore) throws ModuleScoreException,SQLException;
	
}
