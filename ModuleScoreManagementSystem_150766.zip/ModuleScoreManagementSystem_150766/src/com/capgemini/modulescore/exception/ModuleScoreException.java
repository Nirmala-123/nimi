package com.capgemini.modulescore.exception;

public class ModuleScoreException extends Exception{
	String excep;

	public ModuleScoreException(String excep) {
	
		this.excep = excep;
	}
	public String toString(){
		return excep;
	}
}
