package com.capgemini.modulescore.util;

import java.sql.Connection;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.capgemini.modulescore.exception.ModuleScoreException;
public class DBConnection {
	private static Connection connection;
	public static Connection getConnection() throws ModuleScoreException{
		try {
			
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			connection=ds.getConnection();
		} catch (Exception e) {
			throw new ModuleScoreException("Database connection problem.");
		}
		
return connection;
} 
}
