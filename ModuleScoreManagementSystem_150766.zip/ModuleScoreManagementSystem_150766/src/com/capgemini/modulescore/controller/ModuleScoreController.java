package com.capgemini.modulescore.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.modulescore.bean.ModuleScoreBean;
import com.capgemini.modulescore.exception.ModuleScoreException;
import com.capgemini.modulescore.service.IModuleScore;
import com.capgemini.modulescore.service.IModuleScoreImpl;

/**
 * Servlet implementation class ModuleScoreController
 */
@WebServlet("/ModuleScoreController")
public class ModuleScoreController extends HttpServlet {
	ModuleScoreBean moduleScore=new ModuleScoreBean();
	IModuleScore imodScore=new IModuleScoreImpl();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleScoreController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<ModuleScoreBean> traineeId=new ArrayList();
		try{
		traineeId=imodScore.fetchTrainees();
		}
		catch(Exception e){
			System.out.println(e);
		}
		request.setAttribute("trainee",traineeId);
		request.getRequestDispatcher("/AddAssessment.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int mpt,mtt,assignment,grade=0;
		double weightageMpt=0.7,weightageMtt=0.15,weightageAssignment=0.15;
		moduleScore.setTraineeId(Integer.parseInt(request.getParameter("trainee")));
		moduleScore.setModuleName(request.getParameter("module"));
		try{
		
		//Checking whether TraineeId and Module Name exists in table or not	
		
		if(imodScore.traineeCheck(moduleScore))
		{
			throw new ModuleScoreException("");
			
		}
		
		else{
		mpt=Integer.parseInt(request.getParameter("mpt"));
		moduleScore.setMpt(mpt);
		mtt=Integer.parseInt(request.getParameter("mtt"));
		moduleScore.setMtt(mtt);
		assignment=Integer.parseInt(request.getParameter("assignment"));
		moduleScore.setAssignmentScore(assignment);
		int total=(int)((mpt*weightageMpt)+(mtt*weightageMtt)+(weightageAssignment*assignment));
		moduleScore.setTotal(total);
		
		//Grade Calculation
		
		if(total>=0 && total<=49){
			grade=0;
		}
		else if(total>=50 && total<=59){
			grade=1;
		}
		else if(total>=60 && total<=69){
			grade=2;
		}
		else if(total>=70 && total<=79){
			grade=3;
		}
		else if(total>=80 && total<=89){
			grade=4;
		}
		else if(total>=90 && total<=99){
			grade=5;
		}
		
		moduleScore.setGrade(grade);
		try{
			if(imodScore.addAssessmentScore(moduleScore)){
				request.setAttribute("module", moduleScore);
				request.getRequestDispatcher("/ModuleScore.jsp").forward(request,response);
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
		catch(Exception e)
		{
			 request.setAttribute("error","Trainee id and Module Already exists");
				doGet(request,response);
			//response.sendRedirect("AddAssessment.jsp");
		}
}
}