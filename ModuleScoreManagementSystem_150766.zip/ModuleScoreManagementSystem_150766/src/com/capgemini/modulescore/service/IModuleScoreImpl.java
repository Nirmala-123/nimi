package com.capgemini.modulescore.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.modulescore.bean.ModuleScoreBean;
import com.capgemini.modulescore.dao.*;
import com.capgemini.modulescore.exception.ModuleScoreException;

public class IModuleScoreImpl implements IModuleScore{

	

	//------------------------ 1.Module Score Management System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	fetchTrainees()
		 - Input Parameters	:	void
		 - Return Type		:	ArrayList<ModuleScoreBean>
		 - Throws			:  	ModuleScoreException,SQLException
		 - Author			:	S.Venkata Sai Kumar
		 - Creation Date	:	02/7/2018
		 - Description		:	Fetching traineeid for displaying it in form.
		 ********************************************************************************************************/
	@Override
	public ArrayList<ModuleScoreBean> fetchTrainees() throws ModuleScoreException, SQLException {
		IModuleScoreDao ie=new IModuleScoreDaoImpl();
		return ie.fetchTrainees();
	}

	
	
	//------------------------ 1.Module Score Management System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addAssessmentScore(ModuleScoreBean moduleScore)
	 - Input Parameters	:	ModuleScoreBean
	 - Return Type		:	boolean
	 - Throws			:  	ModuleScoreException,SQLException
	 - Author			:	S.Venkata Sai Kumar
	 - Creation Date	:	02/7/2018
	 - Description		:	Inserting calculated Module Score and Grade along with Trainee details to AssessmentScore
	 ********************************************************************************************************/
	
	@Override
	public boolean addAssessmentScore(ModuleScoreBean moduleScore) throws ModuleScoreException, SQLException {
		IModuleScoreDao ie=new IModuleScoreDaoImpl();
		return ie.addAssessmentScore(moduleScore);
		
	}


	//------------------------ 1.Module Score Management System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	traineeCheck(ModuleScoreBean module)
	 - Input Parameters	:	ModuleScoreBean
	 - Return Type		:	boolean
	 - Throws			:  	ModuleScoreException,SQLException
	 - Author			:	S.Venkata Sai Kumar
	 - Creation Date	:	02/7/2018
	 - Description		:	Checking For Trainee
	 ********************************************************************************************************/
	@Override
	public boolean traineeCheck(ModuleScoreBean module)
			throws ModuleScoreException, SQLException {
		IModuleScoreDao ie=new IModuleScoreDaoImpl();
		return ie.traineeCheck(module);
		
	}

}
