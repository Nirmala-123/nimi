package com.capgemini.modulescore.service;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.modulescore.bean.*;
import com.capgemini.modulescore.exception.ModuleScoreException;
public interface IModuleScore {
	public ArrayList<ModuleScoreBean> fetchTrainees() throws ModuleScoreException,SQLException;
	public boolean addAssessmentScore(ModuleScoreBean moduleScore) throws ModuleScoreException,SQLException;
	public boolean traineeCheck(ModuleScoreBean module) throws ModuleScoreException,SQLException;
}
