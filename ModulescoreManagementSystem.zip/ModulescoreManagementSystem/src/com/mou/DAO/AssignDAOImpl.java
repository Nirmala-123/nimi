package com.mou.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mou.util.DBConnection;
import com.mou.bean.AssessmentBean;
import com.mou.DAO.IAssessmentDAO;

public class AssignDAOImpl implements IAssessmentDAO {

	@Override
	public void addassesment(AssessmentBean assbean) throws SQLException {
		try{
		// TODO Auto-generated method stub
		Connection conn=DBConnection.getConnection();
		PreparedStatement preparedstatement=conn.prepareStatement(IQuerryMapper.INSERTMARKS);
		preparedstatement.setLong(1,assbean.getTraineeid());
		preparedstatement.setString(2,assbean.getModulename());
		preparedstatement.setFloat(3,assbean.getMpt());
		preparedstatement.setFloat(4,assbean.getMtt());
		preparedstatement.setFloat(5,assbean.getAssignment());
		preparedstatement.setFloat(6,assbean.getTotalmarks());
		preparedstatement.setFloat(7,assbean.getTotalmarks());
		preparedstatement.executeUpdate();
		
        		}
		catch(SQLException se){
			se.printStackTrace();
		}
		}
}
